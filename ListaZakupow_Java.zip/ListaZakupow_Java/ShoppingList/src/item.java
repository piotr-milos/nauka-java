public class item {
    private String name;
    private boolean bought;

    public item(String name)
    {
        this.name = name;
        this.bought = false;
    }
    public String GetName()
    {
        return name;
    }
    public boolean isBought()
    {
        return bought;
    }
    public void setBought(boolean bought)
    {
        this.bought = bought;
    }

    @Override
    public String toString() {
        return (bought ? "[X] " : "[ ] ") + name;
    }
}
