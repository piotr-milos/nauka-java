import java.util.Scanner;
import java.util.ArrayList;

class ShoppingListApp
{
    public void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        ShoppingList list = new ShoppingList();

        boolean running = true;

        while (running)
        {
            System.out.println("------Lista Zakupów ------");
            System.out.println("1. Dodaj produkt");
            System.out.println("2. Wyswietl liste");
            System.out.println("3. Usuń produkt");
            System.out.println("4. Oznacz jako kupione");
            System.out.println("5. Wyjdź");

            System.out.println("Wybierz opcje: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch(choice)
            {
                case 1:
                    System.out.println("Podaj nazwe: ");
                    String name = scanner.nextLine();
                    list.addItem(name);
                    break;
                case 2:
                    list.displayList();
                    break;
                case 3:
                    System.out.println("Numer do usuniecia: ");
                    int removeIndex = scanner.nextInt() - 1;
                    list.removeItem(removeIndex);
                    break;
                case 4:
                    System.out.println("Numer produktu: ");
                    int boughtIndex = scanner.nextInt() - 1;

            }
        }
    }
}