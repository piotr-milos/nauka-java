import java.util.ArrayList;

public class ShoppingList {
    private ArrayList<item> item;

    public ShoppingList()
    {
        item = new ArrayList<>();
    }
    public void addItem(String name) {
        item.add(new item(name));
    }
    public void removeItem(int index)
    {
        if(index >= 0 && index < item.size())
        {
            item.remove(index);
        }
        else
        {
            System.out.println("Niepoprawny indeks.");
        }
    }
    public void markAsBought(int index)
    {
        if(index >= 0 && index < item.size())
        {
            item.get(index).setBought(true);
        }
        else
        {
            System.out.println("Niepoprawny index.");
        }
    }
    public void displayList()
    {
        if(item.isEmpty())
        {
            System.out.println("Lista jest pusta.");
        }
        for (int i = 0; i < item.size(); i++)
        {
            System.out.println((i + 1) + ". " + item.get(i));
        }
    }
    public int size()
    {
        return item.size();
    }

}
